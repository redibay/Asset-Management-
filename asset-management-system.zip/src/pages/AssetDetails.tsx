import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

interface AssetHistory {
    id: number;
    asset_id: number;
    employee_name: string | null;
    status: string;
    timestamp: string;
}

interface Asset {
  id: number;
  name: string;
  type: string;
  serial_number: string;
  purchase_date: string;
  warranty_end_date: string;
  status: string;
  employee_name: string | null;
  department_name: string | null;
  history: AssetHistory[];
}

export default function AssetDetails() {
  const { id } = useParams<{ id: string }>();
  const [asset, setAsset] = useState<Asset | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAssetDetails = async () => {
      try {
        const response = await fetch(`/api/assets/${id}`);
        if (!response.ok) {
          throw new Error('Failed to fetch asset details');
        }
        const data = await response.json();
        setAsset(data);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    };

    fetchAssetDetails();
  }, [id]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
    const [employees, setEmployees] = useState<{id: number, name: string}[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<number | null>(null);
  const [assignError, setAssignError] = useState<string | null>(null);
    const [isAssigning, setIsAssigning] = useState(false);
  const [isReturning, setIsReturning] = useState(false);
  const [isRetiring, setIsRetiring] = useState(false);

  useEffect(() => {
    if (asset?.status === 'available') {
        const fetchEmployees = async () => {
            try {
                const response = await fetch('/api/employees');
                if (!response.ok) {
                    throw new Error('Failed to fetch employees');
                }
                const data = await response.json();
                setEmployees(data);
            } catch (err) {
                setAssignError((err as Error).message);
            }
        };
        fetchEmployees();
    }
  }, [asset]);

  const handleAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmployee) {
        setAssignError('Please select an employee.');
        return;
    }
    setIsAssigning(true);
    setAssignError(null);

    try {
        const response = await fetch(`/api/assets/${id}/assign`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ employee_id: selectedEmployee }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Failed to assign asset');
        }

        // Refetch asset details to show updated status
        const refetchResponse = await fetch(`/api/assets/${id}`);
        const updatedAsset = await refetchResponse.json();
        setAsset(updatedAsset);

    } catch (err) {
        setAssignError((err as Error).message);
    } finally {
        setIsAssigning(false);
    }
  };

  const handleReturn = async () => {
    setIsReturning(true);
    try {
        const response = await fetch(`/api/assets/${id}/return`, { method: 'POST' });
        if (!response.ok) throw new Error('Failed to return asset');
        const updatedAsset = await (await fetch(`/api/assets/${id}`)).json();
        setAsset(updatedAsset);
    } catch (err) {
        setError((err as Error).message);
    } finally {
        setIsReturning(false);
    }
  };

  const handleRetire = async () => {
    setIsRetiring(true);
    try {
        const response = await fetch(`/api/assets/${id}/retire`, { method: 'POST' });
        if (!response.ok) throw new Error('Failed to retire asset');
        const updatedAsset = await (await fetch(`/api/assets/${id}`)).json();
        setAsset(updatedAsset);
    } catch (err) {
        setError((err as Error).message);
    } finally {
        setIsRetiring(false);
    }
  };

  if (!asset) return <div>Asset not found</div>;

  return (
    <div>
        <Link to="/assets" className="text-indigo-600 hover:text-indigo-900 mb-4 inline-block">&larr; Back to Assets</Link>
                {asset.status === 'available' && (
            <div className="bg-white shadow-md rounded-lg p-6 mb-6">
                <h2 className="text-xl font-bold mb-4">Assign Asset</h2>
                {assignError && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">{assignError}</div>}
                <form onSubmit={handleAssign}>
                    <div className="flex items-center">
                        <select onChange={(e) => setSelectedEmployee(Number(e.target.value))} className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            <option value="">Select an employee</option>
                            {employees.map(emp => <option key={emp.id} value={emp.id}>{emp.name}</option>)}
                        </select>
                        <button type="submit" disabled={isAssigning} className="ml-4 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50">
                            {isAssigning ? 'Assigning...' : 'Assign'}
                        </button>
                    </div>
                </form>
            </div>
        )}
        <div className="bg-white shadow-md rounded-lg p-6 mb-6">
            <h1 className="text-2xl font-bold mb-4">{asset.name}</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><strong>Type:</strong> {asset.type}</div>
                <div><strong>Serial Number:</strong> {asset.serial_number}</div>
                <div><strong>Purchase Date:</strong> {new Date(asset.purchase_date).toLocaleDateString()}</div>
                <div><strong>Warranty End:</strong> {new Date(asset.warranty_end_date).toLocaleDateString()}</div>
                <div><strong>Status:</strong> <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${asset.status === 'assigned' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{asset.status}</span></div>
                <div><strong>Assigned To:</strong> {asset.employee_name || 'N/A'}</div>
                                <div><strong>Department:</strong> {asset.department_name || 'N/A'}</div>
            </div>
            <div className="mt-6 flex space-x-4">
                {asset.status === 'assigned' && (
                    <button onClick={handleReturn} disabled={isReturning} className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-yellow-600 hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 disabled:opacity-50">
                        {isReturning ? 'Returning...' : 'Return Asset'}
                    </button>
                )}
                {asset.status !== 'retired' && (
                     <button onClick={handleRetire} disabled={isRetiring} className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:opacity-50">
                        {isRetiring ? 'Retiring...' : 'Retire Asset'}
                    </button>
                )}
            </div>
        </div>

        <div className="bg-white shadow-md rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Asset History</h2>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assigned To</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {asset.history.map((record) => (
                            <tr key={record.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(record.timestamp).toLocaleString()}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.status}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.employee_name || 'N/A'}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
  );
}
