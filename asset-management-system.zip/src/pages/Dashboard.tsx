export default function Dashboard() {
  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <p>Welcome to the Asset Management System. Use the navigation to view assets and manage employees.</p>
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        <div className="bg-gray-100 p-4 rounded-lg">
          <h2 className="text-lg font-semibold">Total Assets</h2>
          <p className="text-3xl font-bold">128</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg">
          <h2 className="text-lg font-semibold">Assigned Assets</h2>
          <p className="text-3xl font-bold">96</p>
        </div>
        <div className="bg-gray-100 p-4 rounded-lg">
          <h2 className="text-lg font-semibold">Available Assets</h2>
          <p className="text-3xl font-bold">32</p>
        </div>
      </div>
    </div>
  );
}
