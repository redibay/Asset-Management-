import express from 'express';
import db from '../db/database';

const router = express.Router();

// Get all assets
router.get('/assets', (req, res) => {
  try {
    const assets = db.prepare('SELECT a.*, e.name as employee_name, d.name as department_name FROM assets a LEFT JOIN employees e ON a.employee_id = e.id LEFT JOIN departments d ON a.department_id = d.id').all();
    res.json(assets);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Get all employees
router.get('/employees', (req, res) => {
  try {
    const employees = db.prepare('SELECT e.*, d.name as department_name FROM employees e LEFT JOIN departments d ON e.department_id = d.id').all();
    res.json(employees);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Get all departments
router.get('/departments', (req, res) => {
  try {
    const departments = db.prepare('SELECT * FROM departments').all();
    res.json(departments);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Get a single asset by ID with its history
router.get('/assets/:id', (req, res) => {
  try {
    const asset = db.prepare('SELECT a.*, e.name as employee_name, d.name as department_name FROM assets a LEFT JOIN employees e ON a.employee_id = e.id LEFT JOIN departments d ON a.department_id = d.id WHERE a.id = ?').get(req.params.id);
    if (asset) {
      const history = db.prepare('SELECT ah.*, e.name as employee_name FROM asset_history ah LEFT JOIN employees e ON ah.employee_id = e.id WHERE ah.asset_id = ? ORDER BY ah.timestamp DESC').all(req.params.id);
      res.json({ ...asset, history });
    } else {
      res.status(404).json({ error: 'Asset not found' });
    }
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Add a new asset
router.post('/assets', (req, res) => {
    try {
        const { name, type, serial_number, purchase_date, warranty_end_date, department_id } = req.body;
        if (!name || !type) {
            return res.status(400).json({ error: 'Name and type are required' });
        }

        const insertAsset = db.prepare(
            'INSERT INTO assets (name, type, serial_number, purchase_date, warranty_end_date, department_id) VALUES (?, ?, ?, ?, ?, ?)'
        );
        const result = insertAsset.run(name, type, serial_number, purchase_date, warranty_end_date, department_id);

        const newAssetId = result.lastInsertRowid;

        const insertHistory = db.prepare(
            'INSERT INTO asset_history (asset_id, status) VALUES (?, ?)'
        );
        insertHistory.run(newAssetId, 'available');

        res.status(201).json({ id: newAssetId });
    } catch (err) {
        res.status(500).json({ error: (err as Error).message });
    }
});

// Assign an asset to an employee
router.post('/assets/:id/assign', (req, res) => {
    try {
        const { employee_id } = req.body;
        const asset_id = req.params.id;

        if (!employee_id) {
            return res.status(400).json({ error: 'Employee ID is required' });
        }

        const updateAsset = db.prepare(
            'UPDATE assets SET employee_id = ?, status = ? WHERE id = ?'
        );
        const result = updateAsset.run(employee_id, 'assigned', asset_id);

        if (result.changes === 0) {
            return res.status(404).json({ error: 'Asset not found' });
        }

        const insertHistory = db.prepare(
            'INSERT INTO asset_history (asset_id, employee_id, status) VALUES (?, ?, ?)'
        );
        insertHistory.run(asset_id, employee_id, 'assigned');

        res.status(200).json({ message: 'Asset assigned successfully' });
    } catch (err) {
        res.status(500).json({ error: (err as Error).message });
    }
});

// Return an asset
router.post('/assets/:id/return', (req, res) => {
    try {
        const asset_id = req.params.id;

        const updateAsset = db.prepare(
            'UPDATE assets SET employee_id = NULL, status = ? WHERE id = ?'
        );
        const result = updateAsset.run('available', asset_id);

        if (result.changes === 0) {
            return res.status(404).json({ error: 'Asset not found or already available' });
        }

        const insertHistory = db.prepare(
            'INSERT INTO asset_history (asset_id, status) VALUES (?, ?)'
        );
        insertHistory.run(asset_id, 'available');

        res.status(200).json({ message: 'Asset returned successfully' });
    } catch (err) {
        res.status(500).json({ error: (err as Error).message });
    }
});

// Retire an asset
router.post('/assets/:id/retire', (req, res) => {
    try {
        const asset_id = req.params.id;

        const updateAsset = db.prepare(
            'UPDATE assets SET status = ? WHERE id = ?'
        );
        const result = updateAsset.run('retired', asset_id);

        if (result.changes === 0) {
            return res.status(404).json({ error: 'Asset not found' });
        }

        const insertHistory = db.prepare(
            'INSERT INTO asset_history (asset_id, status) VALUES (?, ?)'
        );
        insertHistory.run(asset_id, 'retired');

        res.status(200).json({ message: 'Asset retired successfully' });
    } catch (err) {
        res.status(500).json({ error: (err as Error).message });
    }
});

export default router;
