import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import db from '../db/database';

const router = express.Router();
const saltRounds = 10;
const jwtSecret = process.env.JWT_SECRET || 'your_jwt_secret';

// Register a new employee
router.post('/register', (req, res) => {
    try {
        const { name, email, password, department_id } = req.body;
        if (!name || !email || !password) {
            return res.status(400).json({ error: 'Name, email, and password are required' });
        }

        const salt = bcrypt.genSaltSync(saltRounds);
        const hash = bcrypt.hashSync(password, salt);

        const insertEmployee = db.prepare(
            'INSERT INTO employees (name, email, password, department_id) VALUES (?, ?, ?, ?)'
        );
        const result = insertEmployee.run(name, email, hash, department_id);

        res.status(201).json({ id: result.lastInsertRowid });
    } catch (err) {
        res.status(500).json({ error: (err as Error).message });
    }
});

// Login for employees and admin
router.post('/login', (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        let user: any;
        const admin = db.prepare('SELECT * FROM admin WHERE email = ?').get(email);
        if (admin) {
            user = admin;
        } else {
            const employee = db.prepare('SELECT * FROM employees WHERE email = ?').get(email);
            user = employee;
        }

        if (!user || !bcrypt.compareSync(password, user.password)) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign({ id: user.id, role: user.role }, jwtSecret, { expiresIn: '1h' });

        res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production' });
        res.json({ id: user.id, name: user.name, email: user.email, role: user.role });

    } catch (err) {
        res.status(500).json({ error: (err as Error).message });
    }
});

// Logout
router.post('/logout', (req, res) => {
    res.clearCookie('token');
    res.json({ message: 'Logged out successfully' });
});

// Get current user
router.get('/me', (req, res) => {
    const token = req.cookies.token;
    if (!token) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
        const decoded = jwt.verify(token, jwtSecret) as { id: number, role: string };
        let user: any;
        if (decoded.role === 'admin') {
            user = db.prepare('SELECT id, email, role FROM admin WHERE id = ?').get(decoded.id);
        } else {
            user = db.prepare('SELECT id, name, email, role FROM employees WHERE id = ?').get(decoded.id);
        }
        res.json(user);
    } catch (err) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

export default router;
