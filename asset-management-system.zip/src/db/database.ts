import Database from 'better-sqlite3';

const db = new Database('assets.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'employee',
    department_id INTEGER,
    FOREIGN KEY (department_id) REFERENCES departments(id)
  );
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    serial_number TEXT UNIQUE,
    purchase_date TEXT,
    warranty_end_date TEXT,
    status TEXT NOT NULL DEFAULT 'available', -- available, assigned, in_repair, retired
    employee_id INTEGER,
    department_id INTEGER,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (department_id) REFERENCES departments(id)
  );
`);

db.exec(`
    CREATE TABLE IF NOT EXISTS asset_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_id INTEGER NOT NULL,
        employee_id INTEGER,
        status TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (asset_id) REFERENCES assets(id),
        FOREIGN KEY (employee_id) REFERENCES employees(id)
    );
`);

// Seed initial data if tables are empty
const departmentCount = db.prepare('SELECT COUNT(*) as count FROM departments').get() as { count: number };
if (departmentCount.count === 0) {
    const insertDepartment = db.prepare('INSERT INTO departments (name) VALUES (?)');
    insertDepartment.run('IT');
    insertDepartment.run('Human Resources');
    insertDepartment.run('Marketing');
}

db.exec(`
  CREATE TABLE IF NOT EXISTS admin (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'admin'
  );
`);

// Seed admin user if table is empty
const adminCount = db.prepare('SELECT COUNT(*) as count FROM admin').get() as { count: number };
if (adminCount.count === 0) {
    const insertAdmin = db.prepare('INSERT INTO admin (email, password) VALUES (?, ?)');
    const bcrypt = require('bcrypt');
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync('adminpassword', salt);
    insertAdmin.run('admin@example.com', hash);
}

const assetCount = db.prepare('SELECT COUNT(*) as count FROM assets').get() as { count: number };
if (assetCount.count === 0) {
    const insertAsset = db.prepare('INSERT INTO assets (name, type, serial_number, purchase_date, warranty_end_date, status, employee_id, department_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    insertAsset.run('MacBook Pro 16"', 'Laptop', 'C02Z1234ABCD', '2023-01-15', '2026-01-14', 'assigned', 1, 1);
    insertAsset.run('Dell UltraSharp U2721DE', 'Monitor', 'SN-12345-67890', '2022-11-20', '2025-11-19', 'assigned', 1, 1);
    insertAsset.run('Logitech MX Master 3', 'Mouse', 'M123456789', '2023-01-15', '2025-01-14', 'assigned', 2, 2);
    insertAsset.run('Herman Miller Aeron', 'Chair', 'HM-AERON-001', '2021-05-10', '2031-05-09', 'available', null, 3);
}

export default db;
