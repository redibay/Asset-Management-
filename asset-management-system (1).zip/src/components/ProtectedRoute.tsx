import { useContext } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';

interface ProtectedRouteProps {
    allowedRoles?: ('admin' | 'employee')[];
}

export default function ProtectedRoute({ allowedRoles }: ProtectedRouteProps) {
    const auth = useContext(AuthContext);

    if (auth?.loading) {
        return <div>Loading...</div>; // Or a spinner component
    }

    if (!auth?.user) {
        return <Navigate to="/login" replace />;
    }

    if (allowedRoles && !allowedRoles.includes(auth.user.role)) {
        return <Navigate to="/" replace />; // Or an unauthorized page
    }

    return <Outlet />;
}
